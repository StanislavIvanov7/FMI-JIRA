#include "FinishStageCommand.h"
#include "App/AppData.h"
#include "Exceptions/JiraInvalidArgumentException.h"
#include "Models/Project/Project.h"
#include "Models/Users/User.h"
#include "Utils/Date.h"
#include <iostream>

FinishStageCommand::FinishStageCommand()
    : Command(std::string(NAME), std::string(DESCRIPTION)) {
}

bool FinishStageCommand::requiresLogin() const { return true; }

void FinishStageCommand::execute(const std::vector<std::string>& args, AppData& data) {
    UserRole role = data.getCurrentUser()->getRole();
    if (role != UserRole::TeachingAssistant && role != UserRole::Lecturer) {
        throw JiraInvalidArgumentException("This command is only available for Teaching Assistants and Lecturers.");
    }

    if (args.size() != 1) {
        throw JiraInvalidArgumentException("Usage: finish-stage <stage_name>");
    }

    std::string stageName = args[0];
    User* currentUser = data.getCurrentUser();
    bool stageFound = false;

    for (const auto& project : data.getProjects()) {
        if (project->hasMember(currentUser->getUsername())) {

            for (auto& stage : project->getStages()) {
                if (stage.getName() == stageName) {

                   
                    stage.finish(Date());

                    std::cout << "Stage [" << stageName << "] has been finished." << std::endl;
                    stageFound = true;
                    return;
                }
            }
        }
    }

    if (!stageFound) {
        std::cout << "Stage '" << stageName << "' not found or access denied." << std::endl;
    }
}